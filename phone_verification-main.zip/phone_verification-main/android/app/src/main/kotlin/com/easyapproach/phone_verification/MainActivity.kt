package com.easyapproach.phone_verification

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
